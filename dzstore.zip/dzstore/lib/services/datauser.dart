import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dzstore/constant.dart';
import 'package:dzstore/models/user.dart';

class UserData {
  FirebaseFirestore firestore = FirebaseFirestore.instance;
  addUser(User user) {
    firestore
        .collection("Users")
        .add({password: user.password, phoneNumber: user.number});
  }

  Stream<QuerySnapshot> loadDataUsers() {
    return firestore.collection("Users").snapshots();
  }

  Future<bool> loadnumbers(phone) async {
    var result = await firestore
        .collection("Users")
        .where(
          null,
          isEqualTo: phone,
        )
        .get();
    return result.docs.isEmpty;
  }
}
