import 'package:dzstore/EnterApp/Login.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';

class SignUp extends StatefulWidget {
  static String id = "Signup";
  @override
  _SignUpState createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  final GlobalKey<FormState> _globalKey = GlobalKey<FormState>();
  String phoneNumber, password, name;
  @override
  Widget build(BuildContext context) {
    return Form(
        key: _globalKey,
        child: Scaffold(
            body: SingleChildScrollView(
          child: Container(
              height: MediaQuery.of(context).size.height,
              decoration: BoxDecoration(
                  gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [Colors.black, Colors.grey[900]])),
              width: double.infinity,
              child: AnimationLimiter(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: AnimationConfiguration.toStaggeredList(
                    duration: const Duration(seconds: 2),
                    childAnimationBuilder: (widget) => SlideAnimation(
                      horizontalOffset: -100,
                      child: FadeInAnimation(
                        child: widget,
                      ),
                    ),
                    children: [
                      Container(
                        margin: EdgeInsets.all(20),
                        decoration: BoxDecoration(
                            color: Color(0xFF222225),
                            borderRadius: BorderRadius.circular(10)),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Center(
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(
                                  "Sign Up ",
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 22,
                                      fontFamily: "Roboto",
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                            ),
                            Center(
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(
                                  "SignUp if you dont have Acc",
                                  style: TextStyle(
                                      fontSize: 14,
                                      color: Colors.grey[600],
                                      fontFamily: "Roboto"),
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(
                                  left: 12, top: 8, bottom: 8),
                              child: Text("Name",
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontFamily: 'Roboto',
                                      fontWeight: FontWeight.bold)),
                            ),
                            buildPadding(
                              "Massil",
                              Icon(
                                Icons.person,
                                color: Colors.grey[600],
                              ),
                              name,
                              (val) {
                                if (val.isEmpty) {
                                  return "Name Cant Be Empty";
                                }
                                if (val.length < 4) {
                                  return "Name Cant be less than 4 letters";
                                }
                              },
                              TextInputType.name,
                              LengthLimitingTextInputFormatter(16),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(
                                  left: 12, top: 8, bottom: 8),
                              child: Text("Phone Number",
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontFamily: 'Roboto',
                                      fontWeight: FontWeight.bold)),
                            ),
                            buildPadding(
                              "0675441798",
                              Icon(
                                Icons.phone,
                                color: Colors.grey[600],
                              ),
                              phoneNumber,
                              (val) {
                                if (val.isEmpty) {
                                  return "Phone Number Cant Be Empty";
                                }
                                if (val.length < 10) {
                                  var ok = 10 - val.length;
                                  return "You mess $ok numbers";
                                }
                              },
                              TextInputType.number,
                              new LengthLimitingTextInputFormatter(10),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(
                                  left: 12, top: 8, bottom: 8),
                              child: Text("Password",
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontFamily: 'Roboto',
                                      fontWeight: FontWeight.bold)),
                            ),
                            buildPadding(
                              "*******",
                              Icon(
                                Icons.lock,
                                color: Colors.grey[600],
                              ),
                              password,
                              (val) {
                                if (val.isEmpty) {
                                  return "Password Cant Be Empty";
                                }
                                if (val.length < 6) {
                                  return "Bad Password";
                                }
                              },
                              TextInputType.visiblePassword,
                              LengthLimitingTextInputFormatter(20),
                            ),
                            Center(
                              child: Padding(
                                padding: const EdgeInsets.only(top: 26),
                                child: Builder(
                                  builder: (context) => RaisedButton(
                                    child: Text(
                                      "SignUp",
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold,
                                          fontFamily: "Roboto",
                                          fontSize: 18),
                                    ),
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 70, vertical: 10),
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(20)),
                                    color: Colors.deepPurple,
                                    onPressed: () {
                                      if (_globalKey.currentState.validate()) {
                                        if (phoneNumber == "1") {
                                          showDialog(
                                              builder: (context) {
                                                return AlertDialog(
                                                  backgroundColor:
                                                      Colors.grey[900],
                                                  content: Container(
                                                    child: Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceAround,
                                                      children: [
                                                        Text(
                                                          "Loading ...",
                                                          style: TextStyle(
                                                              fontSize: 20,
                                                              color: Colors
                                                                  .grey[400],
                                                              fontFamily:
                                                                  "Roboto"),
                                                        ),
                                                        CircularProgressIndicator(
                                                          backgroundColor:
                                                              Colors.deepPurple,
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                );
                                              },
                                              context: context);
                                        } else {
                                          Scaffold.of(context)
                                              .showSnackBar(SnackBar(
                                            content:
                                                Text("Invalid Phone Number"),
                                          ));
                                        }
                                      }
                                    },
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(
                                  top: 20, right: 50, left: 50),
                              child: Divider(
                                color: Colors.grey[600],
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(20),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceAround,
                                children: [
                                  Text(
                                    "You  Have Account ?",
                                    style: TextStyle(color: Colors.grey[600]),
                                  ),
                                  InkWell(
                                    onTap: () {
                                      Navigator.push(context, MaterialPageRoute(
                                          builder: (BuildContext context) {
                                        return Login();
                                      }));
                                    },
                                    child: Text(
                                      "Login",
                                      style: TextStyle(
                                          color: Colors.purple, fontSize: 16),
                                    ),
                                  )
                                ],
                              ),
                            )
                          ],
                        ),
                        padding: EdgeInsets.all(8),
                        width: double.infinity,
                      )
                    ],
                  ),
                ),
              )),
        )));
  }

  Padding buildPadding(hint, icon, something, validator, keybordtype, ok) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: TextFormField(
        inputFormatters: [ok],
        style: TextStyle(color: Colors.white, fontSize: 17),
        decoration: InputDecoration(

            //hint Text
            hintStyle: TextStyle(color: Colors.grey[600]),
            hintText: hint,
            filled: true,
            fillColor: Colors.black,
            prefixIcon: icon,
            enabledBorder: OutlineInputBorder(
                borderSide: BorderSide(
                  color: Colors.black,
                ),
                borderRadius: BorderRadius.circular(10)),
            focusedBorder: OutlineInputBorder(
                borderSide: BorderSide(color: Colors.black),
                borderRadius: BorderRadius.circular(10)),
            errorBorder: OutlineInputBorder(
                borderSide: BorderSide(color: Colors.black),
                borderRadius: BorderRadius.circular(10))),
        validator: validator,
        onChanged: (val) {
          something = val;
        },
      ),
    );
  }
}
