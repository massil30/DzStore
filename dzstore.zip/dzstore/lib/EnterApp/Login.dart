import 'package:dzstore/EnterApp/SignUp.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';

class Login extends StatefulWidget {
  static String id = "Login";
  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> {
  String phoneNumber;
  TextEditingController controller;
  final GlobalKey<FormState> _globalKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Form(
        key: _globalKey,
        child: Scaffold(
            backgroundColor: Colors.grey[900],
            body: Container(
              decoration: BoxDecoration(
                  gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [Colors.black, Colors.grey[900]])),
              width: double.infinity,
              child: Center(
                child: AnimationLimiter(
                    child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: AnimationConfiguration.toStaggeredList(
                      duration: const Duration(seconds: 2),
                      childAnimationBuilder: (widget) => SlideAnimation(
                            horizontalOffset: 100,
                            child: FadeInAnimation(
                              child: widget,
                            ),
                          ),
                      children: [
                        Container(
                          margin: EdgeInsets.all(20),
                          decoration: BoxDecoration(
                              color: Color(0xFF222225),
                              borderRadius: BorderRadius.circular(10)),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Center(
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Text(
                                    "Sign in ",
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 22,
                                        fontFamily: "Roboto",
                                        fontWeight: FontWeight.bold),
                                  ),
                                ),
                              ),
                              Center(
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Text(
                                    "Login if you have Acc",
                                    style: TextStyle(
                                        fontSize: 14,
                                        color: Colors.grey[600],
                                        fontFamily: "Roboto"),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(
                                    left: 12, top: 8, bottom: 8),
                                child: Text("Phone Number",
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontFamily: 'Roboto',
                                        fontWeight: FontWeight.bold)),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: TextFormField(
                                  controller: controller,
                                  inputFormatters: [
                                    new LengthLimitingTextInputFormatter(10),
                                  ],
                                  keyboardType: TextInputType.number,
                                  style: TextStyle(
                                      color: Colors.white, fontSize: 17),
                                  decoration: InputDecoration(

                                      //hint Text
                                      hintStyle:
                                          TextStyle(color: Colors.grey[600]),
                                      hintText: "0675441798",
                                      filled: true,
                                      fillColor: Colors.black,
                                      prefixIcon: Icon(
                                        Icons.phone,
                                        color: Colors.grey[700],
                                      ),
                                      enabledBorder: OutlineInputBorder(
                                          borderSide: BorderSide(
                                            color: Colors.black,
                                          ),
                                          borderRadius:
                                              BorderRadius.circular(10)),
                                      focusedBorder: OutlineInputBorder(
                                          borderSide:
                                              BorderSide(color: Colors.black),
                                          borderRadius:
                                              BorderRadius.circular(10)),
                                      errorBorder: OutlineInputBorder(
                                          borderSide:
                                              BorderSide(color: Colors.black),
                                          borderRadius:
                                              BorderRadius.circular(10))),
                                  // ignore: missing_return
                                  validator: (val) {
                                    if (val.isEmpty) {
                                      return "Phone Number Cant Be Empty";
                                    }
                                    if (val.length < 10) {
                                      var ok = 10 - val.length;
                                      return "You mess $ok numbers";
                                    }
                                  },
                                  onChanged: (val) {
                                    phoneNumber = val;
                                  },
                                ),
                              ),
                              Center(
                                child: Padding(
                                  padding: const EdgeInsets.only(top: 26),
                                  child: Builder(
                                    builder: (context) => RaisedButton(
                                      child: Text(
                                        "Login",
                                        style: TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.bold,
                                            fontFamily: "Roboto",
                                            fontSize: 18),
                                      ),
                                      padding: EdgeInsets.symmetric(
                                          horizontal: 70, vertical: 10),
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(20)),
                                      color: Colors.deepPurple,
                                      onPressed: () {
                                        if (_globalKey.currentState
                                            .validate()) {
                                          if (phoneNumber == "1111111111") {
                                            showDialog(
                                              context: context,
                                              builder: (context) {
                                                return AlertDialog(
                                                  backgroundColor:
                                                      Colors.grey[900],
                                                  content: Container(
                                                    height: 200,
                                                    width: 300,
                                                    color: Colors.grey[900],
                                                    child: Column(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceAround,
                                                      children: [
                                                        Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .center,
                                                          children: [
                                                            Container(
                                                                margin: EdgeInsets
                                                                    .only(
                                                                        right:
                                                                            10),
                                                                child: Icon(
                                                                  Icons.phone,
                                                                  size: 30,
                                                                  color: Colors
                                                                      .deepPurple,
                                                                )),
                                                            Text("1111111111",
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        20,
                                                                    color: Colors
                                                                        .white))
                                                          ],
                                                        ),
                                                        TextFormField(
                                                          cursorColor:
                                                              Colors.deepPurple,
                                                          style: TextStyle(
                                                              color:
                                                                  Colors.white),
                                                          decoration:
                                                              InputDecoration(
                                                            fillColor: Colors
                                                                .deepPurple,
                                                            focusColor: Colors
                                                                .deepPurple,
                                                            hoverColor: Colors
                                                                .deepPurple,
                                                            labelStyle:
                                                                TextStyle(
                                                                    color: Colors
                                                                        .white),
                                                            labelText:
                                                                "Password",
                                                          ),
                                                        ),
                                                        RaisedButton(
                                                          shape: RoundedRectangleBorder(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          10)),
                                                          padding: EdgeInsets
                                                              .symmetric(
                                                                  horizontal:
                                                                      50),
                                                          color:
                                                              Colors.deepPurple,
                                                          onPressed: () {},
                                                          child: Text(
                                                            "Login",
                                                            style: TextStyle(
                                                                color: Colors
                                                                    .white,
                                                                fontSize: 18),
                                                          ),
                                                        )
                                                      ],
                                                    ),
                                                  ),
                                                );
                                              },
                                            );
                                          } else {
                                            Scaffold.of(context)
                                                .showSnackBar(SnackBar(
                                              content:
                                                  Text("Invalid Phone Number"),
                                            ));
                                          }
                                        }
                                      },
                                    ),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(
                                    top: 20, right: 50, left: 50),
                                child: Divider(
                                  color: Colors.grey[600],
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(20),
                                child: Row(
                                  children: [
                                    Text(
                                      "You dont Have Account? ",
                                      style: TextStyle(color: Colors.grey[600]),
                                    ),
                                    InkWell(
                                      onTap: () {
                                        Navigator.push(context,
                                            MaterialPageRoute(builder:
                                                (BuildContext context) {
                                          return SignUp();
                                        }));
                                      },
                                      child: Text(
                                        "Create Account",
                                        style: TextStyle(
                                            color: Colors.purple, fontSize: 16),
                                      ),
                                    )
                                  ],
                                ),
                              )
                            ],
                          ),
                          padding: EdgeInsets.all(8),
                          width: double.infinity,
                        ),
                      ]),
                )),
              ),
            )));
  }
}
