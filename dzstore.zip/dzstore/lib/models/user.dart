class User {
  String number;
  String password;
  User({this.number, this.password});
}
