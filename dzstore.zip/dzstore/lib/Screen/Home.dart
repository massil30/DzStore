import 'package:dzstore/Screen/settings.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:residemenu/residemenu.dart';

import '../transltae.dart';
import 'Home/initialpage.dart';

class Home extends StatefulWidget {
  static String id = "Home";
  @override
  _HomeState createState() => _HomeState();
}

int index = 0;
MenuController _menuController;

class _HomeState extends State<Home> with SingleTickerProviderStateMixin {
  @override
  void initState() {
    super.initState();
    _menuController = MenuController(
      vsync: this,
    );
  }

  @override
  Widget build(BuildContext context) {
    var tabs = [home(context, _menuController), Text("Event"), Text("ok")];
    var lan = Provider.of<Translate>(context, listen: true);

    return Scaffold(
      body: ResideMenu.scaffold(
          controller: _menuController,
          leftScaffold: MenuScaffold(
            header: Container(
              height: 100,
              width: 100,
              decoration: BoxDecoration(
                image: DecorationImage(
                    fit: BoxFit.fill, image: AssetImage("images/logo.png")),
                borderRadius: BorderRadius.circular(30),
                color: Colors.white,
              ),
            ),
            children: [
              buildFlatButton("Profile", Icons.person, null),
              buildFlatButton("Settings", Icons.settings, Settings()),
              buildFlatButton("Sign Out", Icons.logout, null),
              buildFlatButton("About", Icons.info, "ok")
            ],
          ),
          decoration: BoxDecoration(color: Colors.grey[850]),
          child: Scaffold(
              bottomNavigationBar: BottomNavigationBar(
                selectedItemColor: Colors.deepPurple,
                currentIndex: index,
                type: BottomNavigationBarType.shifting,
                onTap: (value) {
                  setState(() {
                    index = value;
                  });
                },
                unselectedItemColor: Colors.white,
                selectedFontSize: 18,
                selectedLabelStyle: TextStyle(fontWeight: FontWeight.bold),
                iconSize: 25,
                items: [
                  BottomNavigationBarItem(
                    backgroundColor: Colors.black,
                    icon: Icon(
                      Icons.home,
                    ),
                    label: "Home",
                  ),
                  BottomNavigationBarItem(
                    backgroundColor: Colors.black,
                    icon: Icon(Icons.featured_play_list),
                    label: "Event",
                  ),
                  BottomNavigationBarItem(
                    backgroundColor: Colors.black,
                    icon: Icon(
                      Icons.settings,
                    ),
                    label: "My Orders",
                  ),
                ],
              ),
              body: Directionality(
                  textDirection:
                      lan.isEn == true ? TextDirection.ltr : TextDirection.rtl,
                  child: tabs[index]))),
    );
  }

  buildFlatButton(text, icon, navigator) {
    return ListTile(
      onTap: () {
        Navigator.push(context, MaterialPageRoute(
          builder: (context) {
            return navigator;
          },
        ));
      },
      leading: Icon(
        icon,
        color: Colors.white,
        size: 30,
      ),
      title: Text(
        text,
        style: TextStyle(color: Colors.white, fontSize: 25),
      ),
    );
  }
}
