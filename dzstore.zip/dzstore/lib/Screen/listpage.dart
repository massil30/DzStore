import 'package:flutter/material.dart';

class ListOffers extends StatefulWidget {
  static String id = "Offers";
  @override
  _ListOffersState createState() => _ListOffersState();
}

class _ListOffersState extends State<ListOffers> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.black,
          title: Text(
            'Netflix',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              Container(
                decoration: BoxDecoration(
                    color: Colors.black,
                    border: Border.all(color: Colors.black)),
                height: 250,
                child: Stack(
                  children: [
                    Positioned.fill(
                      child: Container(
                        alignment: Alignment.topCenter,
                        width: double.infinity,
                        child: Image.network(
                          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRoNLkeO3gsU4WNcZRM_q9XUp2g6e1T_EtNEg&usqp=CAU",
                          height: 200,
                          fit: BoxFit.cover,
                          width: 500,
                        ),
                      ),
                    ),
                    Positioned(
                        top: 160,
                        left: 170,
                        child: Container(
                          height: 70,
                          decoration: BoxDecoration(
                              border: Border.all(color: Colors.white),
                              image: DecorationImage(
                                fit: BoxFit.fill,
                                image: AssetImage("images/backnetflix.png"),
                              ),
                              color: Colors.blue,
                              borderRadius: BorderRadius.circular(20)),
                          width: 70,
                        )),
                  ],
                ),
              ),
              Container(
                width: double.infinity,
                decoration: BoxDecoration(
                    border: Border.all(color: Colors.black),
                    gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Colors.black, Colors.grey[900]])),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Text(
                        "NETFLIX",
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 20,
                            color: Colors.white),
                      ),
                    ),
                    Center(
                      child: Padding(
                        padding: const EdgeInsets.all(15),
                        child: Text(
                          "4 Types Of Accounts",
                          style: TextStyle(
                              fontSize: 16,
                              color: Colors.white,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                    Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 80),
                        child: Container(
                          height: 10,
                          decoration: BoxDecoration(
                              color: Colors.grey[850],
                              borderRadius: BorderRadius.circular(10)),
                        )),
                    SingleChildScrollView(
                      child: Container(
                        decoration: BoxDecoration(
                            color: Colors.grey[850],
                            borderRadius: BorderRadius.circular(10)),
                        margin: EdgeInsets.only(
                          top: 10,
                          bottom: 5,
                          left: 5,
                          right: 5,
                        ),
                        padding: const EdgeInsets.all(10),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                Container(
                                  height: 70,
                                  decoration: BoxDecoration(
                                      border: Border.all(
                                          width: 0.2, color: Colors.grey[700]),
                                      image: DecorationImage(
                                        fit: BoxFit.fill,
                                        image: AssetImage(
                                            "images/backnetflix.png"),
                                      ),
                                      color: Colors.blue,
                                      borderRadius: BorderRadius.circular(20)),
                                  width: 70,
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(13),
                                  child: Column(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        "Premuim",
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            color: Colors.grey[300],
                                            fontSize: 20),
                                      ),
                                      Text(
                                        "11.9\$",
                                        style: TextStyle(
                                            color: Colors.grey[300],
                                            fontSize: 20,
                                            fontWeight: FontWeight.bold),
                                      )
                                    ],
                                  ),
                                ),
                              ],
                            ),
                            RaisedButton(
                              color: Colors.deepPurple,
                              padding: EdgeInsets.all(10),
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10)),
                              onPressed: () {},
                              child: Text(
                                "Add To Cart",
                                style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 20),
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                    Container(
                      decoration: BoxDecoration(
                          color: Colors.grey[850],
                          borderRadius: BorderRadius.circular(10)),
                      margin: EdgeInsets.only(
                        top: 10,
                        left: 5,
                        right: 5,
                        bottom: 5,
                      ),
                      padding: const EdgeInsets.all(10),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Container(
                                height: 70,
                                decoration: BoxDecoration(
                                    border: Border.all(
                                        width: 0.2, color: Colors.grey[700]),
                                    image: DecorationImage(
                                      fit: BoxFit.fill,
                                      image:
                                          AssetImage("images/backnetflix.png"),
                                    ),
                                    color: Colors.blue,
                                    borderRadius: BorderRadius.circular(20)),
                                width: 70,
                              ),
                              Padding(
                                padding: const EdgeInsets.all(13),
                                child: Column(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      "Standard",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          color: Colors.grey[300],
                                          fontSize: 20),
                                    ),
                                    Text(
                                      "9.99\$",
                                      style: TextStyle(
                                          color: Colors.grey[300],
                                          fontSize: 20,
                                          fontWeight: FontWeight.bold),
                                    )
                                  ],
                                ),
                              ),
                            ],
                          ),
                          RaisedButton(
                            color: Colors.deepPurple,
                            padding: EdgeInsets.all(10),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10)),
                            onPressed: () {},
                            child: Text(
                              "Add To Cart",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20),
                            ),
                          )
                        ],
                      ),
                    ),
                    Container(
                      decoration: BoxDecoration(
                          color: Colors.grey[850],
                          borderRadius: BorderRadius.circular(10)),
                      margin: EdgeInsets.only(
                        top: 10,
                        left: 5,
                        right: 5,
                        bottom: 5,
                      ),
                      padding: const EdgeInsets.all(10),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Container(
                                height: 70,
                                decoration: BoxDecoration(
                                    border: Border.all(
                                        width: 0.2, color: Colors.grey[700]),
                                    image: DecorationImage(
                                      fit: BoxFit.fill,
                                      image:
                                          AssetImage("images/backnetflix.png"),
                                    ),
                                    color: Colors.blue,
                                    borderRadius: BorderRadius.circular(20)),
                                width: 70,
                              ),
                              Padding(
                                padding: const EdgeInsets.all(13),
                                child: Column(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      "Basic",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          color: Colors.grey[300],
                                          fontSize: 20),
                                    ),
                                    Text(
                                      "7.99\$",
                                      style: TextStyle(
                                          color: Colors.grey[300],
                                          fontSize: 20,
                                          fontWeight: FontWeight.bold),
                                    )
                                  ],
                                ),
                              ),
                            ],
                          ),
                          RaisedButton(
                            color: Colors.deepPurple,
                            padding: EdgeInsets.all(10),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10)),
                            onPressed: () {},
                            child: Text(
                              "Add To Cart",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20),
                            ),
                          )
                        ],
                      ),
                    ),
                    Container(
                      decoration: BoxDecoration(
                          color: Colors.grey[850],
                          borderRadius: BorderRadius.circular(10)),
                      margin: EdgeInsets.only(
                        top: 10,
                        left: 5,
                        right: 5,
                        bottom: 5,
                      ),
                      padding: const EdgeInsets.all(10),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Container(
                                height: 70,
                                decoration: BoxDecoration(
                                    border: Border.all(
                                        width: 0.2, color: Colors.grey[700]),
                                    image: DecorationImage(
                                      fit: BoxFit.fill,
                                      image:
                                          AssetImage("images/backnetflix.png"),
                                    ),
                                    color: Colors.blue,
                                    borderRadius: BorderRadius.circular(20)),
                                width: 70,
                              ),
                              Padding(
                                padding: const EdgeInsets.all(13),
                                child: Column(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      "Mobile",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          color: Colors.white,
                                          fontSize: 20),
                                    ),
                                    Text(
                                      "4.99\$",
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 20,
                                          fontWeight: FontWeight.bold),
                                    )
                                  ],
                                ),
                              ),
                            ],
                          ),
                          RaisedButton(
                            color: Colors.deepPurple,
                            padding: EdgeInsets.all(10),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10)),
                            onPressed: () {},
                            child: Text(
                              "Add To Cart",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20),
                            ),
                          )
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ],
          ),
        ));
  }
}
