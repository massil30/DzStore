import 'package:flutter/material.dart';

final List<String> titles = [
  "",
  "",
  "",
];

final List<Widget> musics = [
  Container(
    width: double.infinity,
    decoration: BoxDecoration(
        image: DecorationImage(
          fit: BoxFit.fill,
          image: AssetImage(
            "images/dezzer.png",
          ),
        ),
        color: Colors.grey[600],
        borderRadius: BorderRadius.circular(20)),
  ),
  Container(
    width: double.infinity,
    decoration: BoxDecoration(
        image: DecorationImage(
          fit: BoxFit.fill,
          image: AssetImage(
            "images/anghami.png",
          ),
        ),
        color: Colors.grey[600],
        borderRadius: BorderRadius.circular(20)),
  ),
  Container(
    width: double.infinity,
    decoration: BoxDecoration(
        image: DecorationImage(
          fit: BoxFit.fill,
          image: NetworkImage(
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQW4tupAVnrL2zBy-uozePnoKQGU4wq_1P5iw&usqp=CAU",
          ),
        ),
        color: Colors.grey[600],
        borderRadius: BorderRadius.circular(20)),
  ),
];

//User
const phoneNumber = "phone Number";
const password = "password";
