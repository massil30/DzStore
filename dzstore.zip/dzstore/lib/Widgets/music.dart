import 'package:flutter/material.dart';
import 'package:vertical_card_pager/vertical_card_pager.dart';

import '../constant.dart';

Scaffold music() {
  return Scaffold(
    appBar: AppBar(
      backgroundColor: Colors.black,
      title: Text(
        "Music",
        style: TextStyle(fontWeight: FontWeight.bold),
      ),
    ),
    body: Container(
      decoration: BoxDecoration(
          gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Colors.black, Colors.grey[900]])),
      child: VerticalCardPager(
          titles: titles, // required
          images: musics, // required
          textStyle: TextStyle(
              color: Colors.black, fontWeight: FontWeight.bold), // optional

          initialPage: 1, // optional
          align: ALIGN.CENTER // optional
          ),
    ),
  );
}
