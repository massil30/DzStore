import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';

gamingTab() {
  return Scaffold(
    appBar: AppBar(
      backgroundColor: Colors.black,
      title: Text(
        "Gaming",
        style: TextStyle(fontWeight: FontWeight.bold),
      ),
    ),
    body: Container(
      decoration: BoxDecoration(
          gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Colors.black, Colors.grey[900]])),
      child: SingleChildScrollView(
        child: AnimationLimiter(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: AnimationConfiguration.toStaggeredList(
              duration: const Duration(milliseconds: 375),
              childAnimationBuilder: (widget) => SlideAnimation(
                verticalOffset: -50.0,
                child: FadeInAnimation(
                  child: widget,
                ),
              ),
              children: [
                Padding(
                  padding: const EdgeInsets.only(bottom: 5, left: 20, top: 10),
                  child: Text(
                    "Popular Games",
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.bold),
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(top: 10, left: 20, bottom: 10),
                  decoration: BoxDecoration(
                      color: Colors.grey[800],
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(10),
                          bottomLeft: Radius.circular(10))),
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: [
                        Container(
                          padding: EdgeInsets.all(20),
                          child: Image.network(
                            "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcS2Gb5rUe6MDECX9JUrjwR1CS9bXb4njTQ6aQ&usqp=CAU",
                            fit: BoxFit.cover,
                            height: 200,
                            width: 150,
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.all(20),
                          child: Image.network(
                            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSpcQu7mILTsAP1xFGSdMlBybI3rrG4ODlU3w&usqp=CAU",
                            fit: BoxFit.cover,
                            height: 200,
                            width: 150,
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.all(20),
                          child: Image.network(
                            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSvCzYu572iz8Otzy2t0vH1Acx-3Xy2o5HH3A&usqp=CAU",
                            fit: BoxFit.cover,
                            height: 200,
                            width: 150,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(bottom: 5, left: 20, top: 10),
                  child: Text(
                    "Battele Royale",
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.bold),
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(top: 10, left: 20, bottom: 10),
                  decoration: BoxDecoration(
                      color: Colors.grey[850],
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(10),
                          bottomLeft: Radius.circular(10))),
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: [
                        Container(
                          padding: EdgeInsets.all(20),
                          child: Image.asset(
                            "images/pubg.png",
                            fit: BoxFit.cover,
                            height: 200,
                            width: 150,
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.all(20),
                          child: Image.network(
                            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSpcQu7mILTsAP1xFGSdMlBybI3rrG4ODlU3w&usqp=CAU",
                            fit: BoxFit.cover,
                            height: 200,
                            width: 150,
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.all(20),
                          child: Image.network(
                            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSvCzYu572iz8Otzy2t0vH1Acx-3Xy2o5HH3A&usqp=CAU",
                            fit: BoxFit.cover,
                            height: 200,
                            width: 150,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(bottom: 5, left: 20, top: 10),
                  child: Text(
                    "MOBA",
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.bold),
                  ),
                ),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      Container(
                        padding: EdgeInsets.all(20),
                        child: Image.asset(
                          "images/dota2.png",
                          fit: BoxFit.cover,
                          height: 200,
                          width: 150,
                        ),
                      ),
                      Container(
                        padding: EdgeInsets.all(20),
                        child: Image.network(
                          "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcS2Gb5rUe6MDECX9JUrjwR1CS9bXb4njTQ6aQ&usqp=CAU",
                          fit: BoxFit.cover,
                          height: 200,
                          width: 150,
                        ),
                      ),
                      Container(
                        padding: EdgeInsets.all(20),
                        child: Image.network(
                          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSvCzYu572iz8Otzy2t0vH1Acx-3Xy2o5HH3A&usqp=CAU",
                          fit: BoxFit.cover,
                          height: 200,
                          width: 150,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    ),
  );
}
