import 'package:flutter/material.dart';

ok(context) {
  showDialog(
      builder: (context) {
        return AlertDialog(
          backgroundColor: Colors.grey[900],
          content: Container(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Text(
                  "Loading ...",
                  style: TextStyle(
                      fontSize: 20,
                      color: Colors.grey[400],
                      fontFamily: "Roboto"),
                ),
                CircularProgressIndicator(
                  backgroundColor: Colors.deepPurple,
                ),
              ],
            ),
          ),
        );
      },
      context: context);
}
