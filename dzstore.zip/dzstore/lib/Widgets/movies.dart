import 'package:dzstore/Screen/listpage.dart';
import 'package:dzstore/constant.dart';
import 'package:flutter/material.dart';
import 'package:vertical_card_pager/vertical_card_pager.dart';

Scaffold movies(context) {
  final List<Widget> movies = [
    InkWell(
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
            image: DecorationImage(
              fit: BoxFit.fill,
              image: AssetImage(
                "images/netflix.png",
              ),
            ),
            color: Colors.grey[600],
            borderRadius: BorderRadius.circular(20)),
      ),
    ),
    Container(
      width: double.infinity,
      decoration: BoxDecoration(
          image: DecorationImage(
            fit: BoxFit.fill,
            image: AssetImage(
              "images/p.png",
            ),
          ),
          color: Colors.grey[600],
          borderRadius: BorderRadius.circular(20)),
    ),
    Container(
      width: double.infinity,
      decoration: BoxDecoration(
          color: Colors.grey[600], borderRadius: BorderRadius.circular(20)),
      child: Image(
        loadingBuilder: (context, child, loadingProgress) {
          return Container(
              decoration: BoxDecoration(
                  color: Colors.white, borderRadius: BorderRadius.circular(20)),
              width: double.infinity,
              child: Center(
                  child: CircularProgressIndicator(
                backgroundColor: Colors.deepPurple,
                semanticsLabel: "Loading ...",
              )));
        },
        image: NetworkImage(
          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSpgLGO2cNzBuyVCZ5CUn6c4Pf0ElhtewD1zQ&usqp=CAU",
        ),
        fit: BoxFit.cover,
      ),
    ),
  ];

  return Scaffold(
    appBar: AppBar(
      backgroundColor: Colors.black,
      title: Text(
        "Movies",
        style: TextStyle(fontWeight: FontWeight.bold),
      ),
    ),
    body: Container(
      decoration: BoxDecoration(
          gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Colors.black, Colors.grey[900]])),
      child: VerticalCardPager(
          titles: titles, // required
          images: movies, // required
          textStyle: TextStyle(
              color: Colors.black, fontWeight: FontWeight.bold), // optional
          onSelectedItem: (index) {
            if (index == 0) {
              Navigator.pushNamed(context, ListOffers.id);
            }
          },
          initialPage: 1, // optional
          align: ALIGN.CENTER // optional
          ),
    ),
  );
}
